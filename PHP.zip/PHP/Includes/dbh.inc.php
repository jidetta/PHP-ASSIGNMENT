<?php

$serverName = "localhost";
$dBUsername = "host";
$dBPassword = "";
$dBName = "php";

$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
    die("Connection Failed:" . mysqli_connect_error());
}

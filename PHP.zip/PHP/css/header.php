<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>PHP Project 01</title>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,1">
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        
      <nav>
        <div class="wrapper">
            <a href="index.php"><img src="img/logo-white.png" alt="Blogs logo">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="discover.php">About Us</a></li>
                <li><a href="blog.php">Find Blogs</a></li>
                <?php
                  if (isset($_SESSION["userUid"])) {
                    echo "<li><a href='profile.php'>Profile Page</a></li>";
                    echo "<li><a href='logout.php'>Log Out</a></li>";
                  }
                  else {
                    echo "<li><a href='signup.php'>Sign Up</a></li>";
                    echo "<li><a href='login.php'>Log In</a></li>";
                  }
                ?>
            </ul>
        </div>
    </nav>

<div class="wrapper">
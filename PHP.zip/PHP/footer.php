</div>
</body>
</html>

<script scr="js/script.js"></script>